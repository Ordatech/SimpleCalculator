package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    boolean isNew = true;
    String newNum= "";
    String num="";
    String op="";
    TextView history, result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        history = findViewById(R.id.textHistory);
        result = findViewById(R.id.textResult);
    }

    public void funcButton(View view) {

        Button btn = (Button) view;
        if(isNew && op == "") {
            history.setText(btn.getText());
            isNew = false; }
        else
            history.append(btn.getText());
    }

    public void clearButton(View view) {
        result.setText("0");
        history.setText("0");
        isNew = true;
    }

    public void operatorButton(View view) {
       // isNew = true;
        num = history.getText().toString();
        Button btn = (Button) view;
            switch (view.getId()) {
                case R.id.buttonTimes:
                    op = "*";
                    history.append(btn.getText());
                    break;
                case R.id.buttonDivide:
                    op = "/";
                    history.append(btn.getText());
                    break;
                case R.id.buttonPlus:
                    op = "+";
                    history.append(btn.getText());
                    break;
                case R.id.buttonMinus:
                    op = "-";
                    history.append(btn.getText());
                    break;
            }
    }

    public void equalsButton(View view){
        newNum = (history.getText().toString()).substring(history.getText().toString().lastIndexOf(op)+1);
        String finRes = "";
        double res = 0.0;
        switch (op) {
            case "+":
                res = Double.parseDouble(num)+Double.parseDouble(newNum);
                finRes = res+"";
                if(finRes.endsWith(".0")){
                    finRes = finRes.replace(".0", "");
                }
                break;
            case "-":
                res = Double.parseDouble(num)-Double.parseDouble(newNum);
                finRes = res+"";
                if(finRes.endsWith(".0")){
                    finRes = finRes.replace(".0", "");
                }
                break;
            case "*":
                newNum = (history.getText().toString()).substring(history.getText().toString().lastIndexOf("X")+1);
                res = Double.parseDouble(num)*Double.parseDouble(newNum);
                finRes = res+"";
                if(finRes.endsWith(".0")){
                    finRes = finRes.replace(".0", "");
                }
                break;
            case "/":
                res = Double.parseDouble(num)/Double.parseDouble(newNum);
                finRes = res+"";
                if(finRes.endsWith(".0")){
                    finRes = finRes.replace(".0", "");
                }
                break;
        }
        result.setText(finRes);
        num=finRes;
        history.setText(finRes);
        res = 0.0;
        isNew = true;
        op="";
    }
}